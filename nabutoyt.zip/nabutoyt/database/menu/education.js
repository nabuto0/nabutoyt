const education = (pushname, prefix, botName, ownerName) => {
	return `

───────⊹⊱✫⊰⊹───────
║➩ ❍ *${prefix}info*
║➩ ❍ *${prefix}blocklist*
║➩ ❍ *${prefix}chatlist*
║➩ ❍ *${prefix}ping*
║➩ ❍ *${prefix}bugreport*
║➩ ❍ *${prefix}wiki*
║➩ ❍ *${prefix}wikien*
║➩ ❍ *${prefix}nulis*
║➩ ❍ *${prefix}quotes*
║➩ ❍ *${prefix}quotes2*
║➩ ❍ *${prefix}artinama*
║➩ Aumente seu level interagindo no grupo!!
───────⊹⊱✫⊰⊹───────`
}
exports.education = education
