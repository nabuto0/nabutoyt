const search = (pushname, prefix, botName, ownerName) => {
	return `

───────⊹⊱✫⊰⊹───────
║➩ ❍ *${prefix}info*
║➩ ❍ *${prefix}blocklist*
║➩ ❍ *${prefix}chatlist*
║➩ ❍ *${prefix}ping*
║➩ ❍ *${prefix}bugreport*
║➩ ❍ *${prefix}wait*
║➩ ❍ *${prefix}ytsearch*
║➩ ❍ *${prefix}trendtwit*
║➩ ❍ *${prefix}wikien*
║➩ ❍ *${prefix}wiki*
║➩ ❍ *${prefix}neonime*
║➩ Aumente seu level interagindo no grupo!!
───────⊹⊱✫⊰⊹───────`
}
exports.search = search
