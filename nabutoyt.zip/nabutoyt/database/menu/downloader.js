const downloader = (pushname, prefix, botName, ownerName) => {
	return `

───────⊹⊱✫⊰⊹───────
║➩ ❍ *${prefix}info*
║➩ ❍ *${prefix}blocklist*
║➩ ❍ *${prefix}chatlist*
║➩ ❍ *${prefix}ping*
║➩ ❍ *${prefix}bugreport*
║➩ ❍ *${prefix}pinterest*
║➩ ❍ *${prefix}ytmp3*
║➩ ❍ *${prefix}ytmp4*
║➩ ❍ *${prefix}tiktok*
║➩ Aumente seu level interagindo no grupo!!
───────⊹⊱✫⊰⊹───────`
}
exports.downloader = downloader
