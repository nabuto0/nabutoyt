const music = (pushname, prefix, botName, ownerName) => {
        return `
╔══✪〘 Informações 〙✪══


───────⊹⊱✫⊰⊹───────
║➩ ❍ *${prefix}info*
║➩ ❍ *${prefix}blocklist*
║➩ ❍ *${prefix}chatlist*
║➩ ❍ *${prefix}ping*
║➩ ❍ *${prefix}bugreport*
║➩ ❍ *${prefix}play*
║➩ ❍ *${prefix}joox*
║➩ ❍ *${prefix}lirik*
║➩ ❍ *${prefix}chord*
║➩ Aumente seu level interagindo no grupo!!
───────⊹⊱✫⊰⊹───────`
}
exports.music = music
