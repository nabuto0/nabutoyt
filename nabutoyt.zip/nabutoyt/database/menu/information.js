const information = (pushname, prefix, botName, ownerName) => {
        return `

───────⊹⊱✫⊰⊹───────
║➩ ❍ *${prefix}info*
║➩ ❍ *${prefix}blocklist*
║➩ ❍ *${prefix}chatlist*
║➩ ❍ *${prefix}ping*
║➩ ❍ *${prefix}bugreport*
║➩ ❍ *${prefix}bahasa*
║➩ ❍ *${prefix}kodenegara*
║➩ ❍ *${prefix}kbbi*
║➩ ❍ *${prefix}fakta*
║➩ ❍ *${prefix}infocuaca*
║➩ ❍ *${prefix}infogempa*
║➩ ❍ *${prefix}jadwaltvnow*
║➩ ❍ *${prefix}covidcountry*
║➩ Aumente seu level interagindo no grupo!!
───────⊹⊱✫⊰⊹───────`
}
exports.information = information
