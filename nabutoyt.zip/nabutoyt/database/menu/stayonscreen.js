const stayonscreen = (pushname, prefix, botName, ownerName) => {
        return `

───────⊹⊱✫⊰⊹───────
║➩ ❍  *${prefix}info*
║➩ ❍  *${prefix}blocklist*
║➩ ❍  *${prefix}chatlist*
║➩ ❍  *${prefix}ping*
║➩ ❍  *${prefix}bugreport*
║➩ ❍  *${prefix}afk*
║➩ Aumente seu level interagindo no grupo!!
║───────⊹⊱✫⊰⊹───────`
}
exports.stayonscreen = stayonscreen
