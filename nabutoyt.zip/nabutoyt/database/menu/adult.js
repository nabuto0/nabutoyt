const adult = (pushname, prefix, botName, ownerName) => {
        return `

───────⊹⊱✫⊰⊹───────
║➩ ❍ *${prefix}info*
║➩ ❍ *${prefix}blocklist*
║➩ ❍ *${prefix}chatlist*
║➩ ❍ *${prefix}ping*
║➩ ❍ *${prefix}bugreport*
║➩ ❍ *${prefix}randomhentai*
║➩ ❍ *${prefix}nsfwtrap*
║➩ ❍ *${prefix}nsfwneko*
║➩ Aumente seu level interagindo no grupo!!
───────⊹⊱✫⊰⊹───────`
}
exports.adult = adult
