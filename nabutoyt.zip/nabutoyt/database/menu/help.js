const help = (pushname, prefix, botName, ownerName, reqXp, uangku) => {
        return `
  *BOT NABUTO*
 𝙄𝙉𝙁𝙊𝙍𝙈𝘼𝘾̧𝙊̃𝙀𝙎
 NÚMERO DO DONO: wa.me/556993733829
 PREFIXO DO BOT: 「  ${prefix}  」
 Criador: ${botName}
 Nome: ${pushname}️
 SEU XP: ${reqXp}
 DIN DIN: ${uangku}
 CANAL NO YTB: https://youtube.com/channel/UCZEtf9AlsC2zsJQwrfW-44w
   COMANDOS:

  RELACIONADO A SEU LIMITE:

➤ ${prefix}limite (ver seu limite)
➤ ${prefix}buylimite (comprar limite)
➤ ${prefix}bal (ver seu dinheiro)
➤ Aumente seu level interagindo no grupo!!

➤ ${prefix}
  
  *SOBRE O BOT*
  
➤ ${prefix}info [INFORMAÇÕES]

➤ ${prefix}blocklist [LISTA DE BLOCK]

➤ ${prefix}chatlist [LISTA CHAT]

➤ ${prefix}ping [PING DO BOT]

➤ ${prefix}bugreport [REPORTE BUG] ERRO

         CRIAR/FAZER
  
➤ ${prefix}figu [FIGURINHA]

➤ ${prefix}toimg [FIGURINHA EM IMAGEM]

➤ ${prefix}virarmp3 [PEGAR ÁUDIO DE UM VÍDEO DO WPP]


        *MIDIA*
  
➤ ${prefix}trendtwit

➤ ${prefix}randomkpop [FOTO ALEATÓRIA KPOP]

➤ ${prefix}ytsearch [PESQUISAR YTB]

         *FALAR COM BOT*
  
➤ ${prefix}avalie
  
    *DOWNLOAD*
  
➤ ${prefix}images

➤ ${prefix}ytmp3

➤ ${prefix}ytmp4

➤ ${prefix}tiktok

➤ ${prefix}joox

    *MEMES*

➤ ${prefix}meme

➤ ${prefix}nabutojokes

      *SOM*  
      
➤ ${prefix}lirik

➤ ${prefix}chord

  *STALEKAR*
 
➤ ${prefix}tiktokstalk

➤ ${prefix}igstalk

   ANIME
  
➤ ${prefix}neonime

➤ ${prefix}pokemon

➤ ${prefix}loli

➤ ${prefix}waifu

➤ ${prefix}randomanime

➤ ${prefix}husbu

➤ ${prefix}husbu2

➤ ${prefix}buscanime

➤ ${prefix}nekonime

  *CÓDIGOS DE LINGUAGEM*
  
➤ ${prefix}bahasa


    *APENAS PARA DONO*
  
➤ ${prefix}setprefix

➤ ${prefix}block

➤ ${prefix}tm

➤ ${prefix}tmctt

➤ ${prefix}clone

➤ ${prefix}clearall

    *DIVERSÃO*

➤ ${prefix}lgbt

➤ ${prefix}gay

➤ ${prefix}gay2

➤ ${prefix}gado

➤ ${prefix}buc

    *OUTROS*
 
➤ ${prefix}send

➤ ${prefix}wame

➤ ${prefix}virtex

➤ ${prefix}exe

➤ ${prefix}qrcode

➤ ${prefix}afk

➤ ${prefix}timer

➤ ${prefix}fml

➤ ${prefix}fml2
`
}
exports.help = help
