const stalk = (pushname, prefix, botName, ownerName) => {
        return `

───────⊹⊱✫⊰⊹───────
║➩ ❍ *${prefix}info*
║➩ ❍ *${prefix}blocklist*
║➩ ❍ *${prefix}chatlist*
║➩ ❍ *${prefix}ping*
║➩ ❍ *${prefix}bugreport*
║➩ ❍ *${prefix}tiktokstalk*
║➩ ❍ *${prefix}igstalk*
║➩ Aumente seu level interagindo no grupo!!
───────⊹⊱✫⊰⊹───────`
}
exports.stalk = stalk
